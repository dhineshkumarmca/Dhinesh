package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import entity.LibraryUser;
import util.DBConnection;


public class LibraryUserDAO {

    public void addUser(LibraryUser user) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO library_user VALUES (?, ?, ?)"
            );
            ps.setInt(1, user.getId());
            ps.setString(2, user.getName());
            ps.setString(3, user.getEmail());
            ps.executeUpdate();
            conn.close();
            System.out.println("User Added!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewUsers() {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM library_user"
            );
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(rs.getInt(1) + " " +
                                   rs.getString(2) + " " +
                                   rs.getString(3));
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateUser(int id, String name, String email) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE library_user SET name=?, email=? WHERE id=?"
            );
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setInt(3, id);
            ps.executeUpdate();
            conn.close();
            System.out.println("User Updated!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteUser(int id) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM library_user WHERE id=?"
            );
            ps.setInt(1, id);
            ps.executeUpdate();
            conn.close();
            System.out.println("User Deleted!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void findUser(int id) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM library_user WHERE id=?"
            );
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Found: " +
                    rs.getInt(1) + " " +
                    rs.getString(2) + " " +
                    rs.getString(3));
            } else {
                System.out.println("User Not Found");
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void countUsers() {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) FROM library_user"
            );
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Total Users: " + rs.getInt(1));
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
package dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import entity.Book;
import util.DBConnection;



public class BookDAO {

    public void addBook(Book book) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO book VALUES (?, ?, ?)"
            );
            ps.setInt(1, book.getId());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getAuthor());
            ps.executeUpdate();
            conn.close();
            System.out.println("Book Added!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewBooks() {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM book"
            );
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(rs.getInt(1) + " " +
                                   rs.getString(2) + " " +
                                   rs.getString(3));
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateBook(int id, String title, String author) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE book SET title=?, author=? WHERE id=?"
            );
            ps.setString(1, title);
            ps.setString(2, author);
            ps.setInt(3, id);
            ps.executeUpdate();
            conn.close();
            System.out.println("Book Updated!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteBook(int id) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM book WHERE id=?"
            );
            ps.setInt(1, id);
            ps.executeUpdate();
            conn.close();
            System.out.println("Book Deleted!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void findBook(int id) {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM book WHERE id=?"
            );
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Found: " +
                    rs.getInt(1) + " " +
                    rs.getString(2) + " " +
                    rs.getString(3));
            } else {
                System.out.println("Book Not Found");
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void countBooks() {
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) FROM book"
            );
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Total Books: " + rs.getInt(1));
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
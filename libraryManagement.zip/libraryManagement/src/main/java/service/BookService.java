package service;

import dao.BookDAO;
import entity.Book;

public class BookService {

    private BookDAO dao = new BookDAO();

    // CREATE
    public void add(int id, String title, String author) {
        Book book = new Book(id, title, author);
        dao.addBook(book);
    }

    // READ (ALL)
    public void view() {
        dao.viewBooks();
    }

    // UPDATE
    public void update(int id, String title, String author) {
        dao.updateBook(id, title, author);
    }

    // DELETE
    public void delete(int id) {
        dao.deleteBook(id);
    }

    // SEARCH BY ID
    public void find(int id) {
        dao.findBook(id);
    }

    // COUNT
    public void count() {
        dao.countBooks();
    }
}
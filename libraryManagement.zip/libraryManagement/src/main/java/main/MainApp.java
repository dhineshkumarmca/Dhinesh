package main;

import java.util.Scanner;

import service.BookService;
import service.LibraryUserService;

public class MainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        BookService bookService = new BookService();
        LibraryUserService userService = new LibraryUserService();

        while (true) {

            System.out.println("\n===== LIBRARY MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Book");
            System.out.println("2. View Books");
            System.out.println("3. Update Book");
            System.out.println("4. Delete Book");
            System.out.println("5. Find Book");
            System.out.println("6. Count Books");

            System.out.println("7. Add User");
            System.out.println("8. View Users");
            System.out.println("9. Update User");
            System.out.println("10. Delete User");
            System.out.println("11. Find User");
            System.out.println("12. Count Users");

            System.out.println("13. Exit");

            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                // 📘 BOOK OPERATIONS

                case 1:
                    System.out.println("Enter Book ID:");
                    int id = sc.nextInt();
                    sc.nextLine();

                    System.out.println("Enter Title:");
                    String title = sc.nextLine();

                    System.out.println("Enter Author:");
                    String author = sc.nextLine();

                    bookService.add(id, title, author);
                    break;

                case 2:
                    bookService.view();
                    break;

                case 3:
                    System.out.println("Enter Book ID to update:");
                    int upId = sc.nextInt();
                    sc.nextLine();

                    System.out.println("Enter New Title:");
                    String newTitle = sc.nextLine();

                    System.out.println("Enter New Author:");
                    String newAuthor = sc.nextLine();

                    bookService.update(upId, newTitle, newAuthor);
                    break;

                case 4:
                    System.out.println("Enter Book ID to delete:");
                    int delId = sc.nextInt();
                    bookService.delete(delId);
                    break;

                case 5:
                    System.out.println("Enter Book ID to find:");
                    int findId = sc.nextInt();
                    bookService.find(findId);
                    break;

                case 6:
                    bookService.count();
                    break;

                // 👤 USER OPERATIONS

                case 7:
                    System.out.println("Enter User ID:");
                    int uid = sc.nextInt();
                    sc.nextLine();

                    System.out.println("Enter Name:");
                    String name = sc.nextLine();

                    System.out.println("Enter Email:");
                    String email = sc.nextLine();

                    userService.add(uid, name, email);
                    break;

                case 8:
                    userService.view();
                    break;

                case 9:
                    System.out.println("Enter User ID to update:");
                    int uId = sc.nextInt();
                    sc.nextLine();

                    System.out.println("Enter New Name:");
                    String newName = sc.nextLine();

                    System.out.println("Enter New Email:");
                    String newEmail = sc.nextLine();

                    userService.update(uId, newName, newEmail);
                    break;

                case 10:
                    System.out.println("Enter User ID to delete:");
                    int delUid = sc.nextInt();
                    userService.delete(delUid);
                    break;

                case 11:
                    System.out.println("Enter User ID to find:");
                    int findUid = sc.nextInt();
                    userService.find(findUid);
                    break;

                case 12:
                    userService.count();
                    break;

                case 13:
                    System.out.println("Exiting...");
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }
}
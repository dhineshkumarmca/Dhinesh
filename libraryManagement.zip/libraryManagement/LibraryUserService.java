package service;

import dao.LibraryUserDAO;
import entity.LibraryUser;

public class LibraryUserService {

    private LibraryUserDAO dao = new LibraryUserDAO();

    // CREATE
    public void add(int id, String name, String email) {
        LibraryUser user = new LibraryUser(id, name, email);
        dao.addUser(user);
    }

    // READ (ALL)
    public void view() {
        dao.viewUsers();
    }

    // UPDATE
    public void update(int id, String name, String email) {
        dao.updateUser(id, name, email);
    }

    // DELETE
    public void delete(int id) {
        dao.deleteUser(id);
    }

    // SEARCH BY ID
    public void find(int id) {
        dao.findUser(id);
    }

    // COUNT
    public void count() {
        dao.countUsers();
    }
}